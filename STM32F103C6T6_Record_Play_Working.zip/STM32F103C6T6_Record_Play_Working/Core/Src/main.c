/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  * Record and play working good
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <string.h>
#include <stdio.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
typedef struct {
    uint8_t switchNum;
    uint32_t pressTime;
    uint32_t duration;
} SwitchEvent;

typedef enum {
    STATE_IDLE,
    STATE_RECORDING,
    STATE_PLAYING
} SystemState;
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define MAX_EVENTS 100
#define SW_RECORD_PIN GPIO_PIN_0  // SW1 (PA0)
#define SW_PLAY_PIN GPIO_PIN_1    // SW2 (PA1)
#define LED_RECORD_PIN GPIO_PIN_3 // PB3
#define LED_PLAY_PIN GPIO_PIN_4   // PB4

// Other switches
#define SW3_PIN GPIO_PIN_2
#define SW4_PIN GPIO_PIN_3
#define SW5_PIN GPIO_PIN_4
#define SW6_PIN GPIO_PIN_5
#define SW7_PIN GPIO_PIN_6

// Other LEDs
#define LED3_PIN GPIO_PIN_5  // PB5
#define LED4_PIN GPIO_PIN_6  // PB6
#define LED5_PIN GPIO_PIN_6  // PB6
#define LED6_PIN GPIO_PIN_7  // PB7
#define LED7_PIN GPIO_PIN_8  // PB8

#define DEBOUNCE_DELAY 50
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
UART_HandleTypeDef huart1;

/* USER CODE BEGIN PV */
SwitchEvent recordedEvents[MAX_EVENTS];
uint16_t eventCount = 0;
SystemState currentState = STATE_IDLE;
uint32_t recordStartTime = 0;
uint32_t playStartTime = 0;
uint8_t prevRecordState = GPIO_PIN_SET;
uint8_t prevPlayState = GPIO_PIN_SET;
uint8_t prevSwitchStates[5] = {GPIO_PIN_SET, GPIO_PIN_SET, GPIO_PIN_SET, GPIO_PIN_SET, GPIO_PIN_SET};
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART1_UART_Init(void);
/* USER CODE BEGIN PFP */
/* USER CODE BEGIN PFP */
void CheckOtherSwitches(void);
void StartRecording(void);
void StopRecording(void);
void StartPlayback(void);
void StopPlayback(void);
void RecordSwitchEvent(uint8_t switchNum);
void PlaybackEvents(void);
void PrintEventLog(void);
void HandleSwitchPress(uint8_t switchNum, uint8_t state);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART1_UART_Init();
  /* USER CODE BEGIN 2 */
  HAL_GPIO_WritePin(GPIOB, LED_RECORD_PIN, GPIO_PIN_SET);
  HAL_Delay(200);
  HAL_GPIO_WritePin(GPIOB, LED_RECORD_PIN, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(GPIOB, LED_PLAY_PIN, GPIO_PIN_SET);
  HAL_Delay(200);
  HAL_GPIO_WritePin(GPIOB, LED_PLAY_PIN, GPIO_PIN_RESET);

  // Send startup message
  char msg[] = "System Ready\r\n";
  HAL_UART_Transmit(&huart1, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    uint8_t currentRecordState = HAL_GPIO_ReadPin(GPIOA, SW_RECORD_PIN);
    uint8_t currentPlayState = HAL_GPIO_ReadPin(GPIOA, SW_PLAY_PIN);

    // Handle Record button (SW1)
    if (currentRecordState == GPIO_PIN_RESET && prevRecordState == GPIO_PIN_SET) {
        HAL_Delay(DEBOUNCE_DELAY);
        if (currentState == STATE_RECORDING) {
            StopRecording();
        } else if (currentState == STATE_IDLE) {
            StartRecording();
        }
    }
    prevRecordState = currentRecordState;

    // Handle Play button (SW2)
    if (currentPlayState == GPIO_PIN_RESET && prevPlayState == GPIO_PIN_SET) {
        HAL_Delay(DEBOUNCE_DELAY);
        if (currentState == STATE_PLAYING) {
            StopPlayback();
        } else if (currentState == STATE_IDLE && eventCount > 0) {
            StartPlayback();
        }
    }
    prevPlayState = currentPlayState;

    // Check all switches (including record and play)
    CheckOtherSwitches();

    HAL_Delay(10);  // Small delay to reduce CPU load
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0|GPIO_PIN_3|GPIO_PIN_4|GPIO_PIN_5
                          |GPIO_PIN_6|GPIO_PIN_7|GPIO_PIN_8|GPIO_PIN_9, GPIO_PIN_RESET);

  /*Configure GPIO pin : PC13 */
  GPIO_InitStruct.Pin = GPIO_PIN_13;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : PA0 PA1 PA2 PA3
                           PA4 PA5 PA6 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3
                          |GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : PA7 */
  GPIO_InitStruct.Pin = GPIO_PIN_7;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : PB0 PB3 PB4 PB5
                           PB6 PB7 PB8 PB9 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_3|GPIO_PIN_4|GPIO_PIN_5
                          |GPIO_PIN_6|GPIO_PIN_7|GPIO_PIN_8|GPIO_PIN_9;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
void StartRecording(void) {
    currentState = STATE_RECORDING;
    eventCount = 0;
    recordStartTime = HAL_GetTick();
    // Turn on record LED and keep it on
    HAL_GPIO_WritePin(GPIOB, LED_RECORD_PIN, GPIO_PIN_SET);

    char msg[64];
    sprintf(msg, "Recording started at %lu ms\r\n", recordStartTime);
    HAL_UART_Transmit(&huart1, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);
}

void StopRecording(void) {
    currentState = STATE_IDLE;
    uint32_t recordDuration = HAL_GetTick() - recordStartTime;
    // Turn off record LED
    HAL_GPIO_WritePin(GPIOB, LED_RECORD_PIN, GPIO_PIN_RESET);

    char msg[64];
    sprintf(msg, "Recording stopped. Duration: %lu ms. Recorded %d events.\r\n",
            recordDuration, eventCount);
    HAL_UART_Transmit(&huart1, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);
    PrintEventLog();
}

void StartPlayback(void) {
    currentState = STATE_PLAYING;
    playStartTime = HAL_GetTick();
    HAL_GPIO_WritePin(GPIOB, LED_PLAY_PIN, GPIO_PIN_SET);

    char msg[64];
    sprintf(msg, "Playback started at %lu ms\r\n", playStartTime);
    HAL_UART_Transmit(&huart1, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);

    PlaybackEvents();
}

void StopPlayback(void) {
    currentState = STATE_IDLE;
    uint32_t playDuration = HAL_GetTick() - playStartTime;
    HAL_GPIO_WritePin(GPIOB, LED_PLAY_PIN, GPIO_PIN_RESET);

    // Turn off all LEDs
    HAL_GPIO_WritePin(GPIOB, LED3_PIN, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(GPIOB, LED4_PIN, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(GPIOB, LED5_PIN, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(GPIOB, LED6_PIN, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(GPIOB, LED7_PIN, GPIO_PIN_RESET);

    char msg[64];
    sprintf(msg, "Playback stopped. Duration: %lu ms.\r\n", playDuration);
    HAL_UART_Transmit(&huart1, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);
}

void HandleSwitchPress(uint8_t switchNum, uint8_t state) {
    // Blink PC13 for any switch press (on press only)
    if (state == GPIO_PIN_RESET) {
        HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_SET);
        HAL_Delay(100);
        HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET);
    }

    // If recording, control the corresponding LED (except record LED)
    if (currentState == STATE_RECORDING && switchNum != 0) {
        switch(switchNum) {
            case 1: // SW2 (Play)
                HAL_GPIO_WritePin(GPIOB, LED_PLAY_PIN, (state == GPIO_PIN_RESET) ? GPIO_PIN_SET : GPIO_PIN_RESET);
                break;
            case 2: // SW3
                HAL_GPIO_WritePin(GPIOB, LED3_PIN, (state == GPIO_PIN_RESET) ? GPIO_PIN_SET : GPIO_PIN_RESET);
                break;
            case 3: // SW4
                HAL_GPIO_WritePin(GPIOB, LED4_PIN, (state == GPIO_PIN_RESET) ? GPIO_PIN_SET : GPIO_PIN_RESET);
                break;
            case 4: // SW5
                HAL_GPIO_WritePin(GPIOB, LED5_PIN, (state == GPIO_PIN_RESET) ? GPIO_PIN_SET : GPIO_PIN_RESET);
                break;
            case 5: // SW6
                HAL_GPIO_WritePin(GPIOB, LED6_PIN, (state == GPIO_PIN_RESET) ? GPIO_PIN_SET : GPIO_PIN_RESET);
                break;
            case 6: // SW7
                HAL_GPIO_WritePin(GPIOB, LED7_PIN, (state == GPIO_PIN_RESET) ? GPIO_PIN_SET : GPIO_PIN_RESET);
                break;
        }
    }
}

void CheckOtherSwitches(void) {
    uint32_t currentTime = HAL_GetTick();
    if (currentState == STATE_RECORDING) {
        currentTime -= recordStartTime;
    }

    uint8_t currentStates[7] = {
        HAL_GPIO_ReadPin(GPIOA, SW_RECORD_PIN),
        HAL_GPIO_ReadPin(GPIOA, SW_PLAY_PIN),
        HAL_GPIO_ReadPin(GPIOA, SW3_PIN),
        HAL_GPIO_ReadPin(GPIOA, SW4_PIN),
        HAL_GPIO_ReadPin(GPIOA, SW5_PIN),
        HAL_GPIO_ReadPin(GPIOA, SW6_PIN),
        HAL_GPIO_ReadPin(GPIOA, SW7_PIN)
    };

    for (uint8_t i = 0; i < 7; i++) {
        if (currentStates[i] != prevSwitchStates[i]) {
            HAL_Delay(DEBOUNCE_DELAY);
            HandleSwitchPress(i, currentStates[i]);

            if (currentState == STATE_RECORDING && i >= 2 && eventCount < MAX_EVENTS) {
                if (currentStates[i] == GPIO_PIN_RESET) {
                    // Record press event
                    recordedEvents[eventCount].switchNum = i + 1;
                    recordedEvents[eventCount].pressTime = currentTime;
                    recordedEvents[eventCount].duration = 0;
                    eventCount++;
                } else {
                    // Update duration for release
                    for (int j = eventCount - 1; j >= 0; j--) {
                        if (recordedEvents[j].switchNum == i + 1 && recordedEvents[j].duration == 0) {
                            recordedEvents[j].duration = currentTime - recordedEvents[j].pressTime;
                            break;
                        }
                    }
                }
            }
        }
        prevSwitchStates[i] = currentStates[i];
    }
}

void PlaybackEvents(void) {
    uint32_t playbackStart = HAL_GetTick();

    for (uint16_t i = 0; i < eventCount && currentState == STATE_PLAYING; i++) {
        // Wait until event time
        while ((HAL_GetTick() - playbackStart) < recordedEvents[i].pressTime) {
            if (currentState != STATE_PLAYING) return;
        }

        // Handle the LED state change
        switch(recordedEvents[i].switchNum) {
            case 3: HAL_GPIO_TogglePin(GPIOB, LED3_PIN); break;
            case 4: HAL_GPIO_TogglePin(GPIOB, LED4_PIN); break;
            case 5: HAL_GPIO_TogglePin(GPIOB, LED5_PIN); break;
            case 6: HAL_GPIO_TogglePin(GPIOB, LED6_PIN); break;
            case 7: HAL_GPIO_TogglePin(GPIOB, LED7_PIN); break;
        }
    }
    StopPlayback();
}

void PrintEventLog(void) {
    char msg[128];
    uint32_t currentTime = HAL_GetTick();

    // Print header with current time
    sprintf(msg, "\r\n[%lums] Event Log (%d events):\r\n", currentTime, eventCount);
    HAL_UART_Transmit(&huart1, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);

    for (uint16_t i = 0; i < eventCount; i++) {
        sprintf(msg, "[%lums] Event %d: SW%d at %lums (duration %lums)\r\n",
                currentTime,
                i+1,
                recordedEvents[i].switchNum,
                recordedEvents[i].pressTime,
                recordedEvents[i].duration);
        HAL_UART_Transmit(&huart1, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);
    }
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
